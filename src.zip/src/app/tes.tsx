import { useState } from "react";
import { Pressable, Text, View } from "react-native";

import { styles } from "../styles/HomeStyle";

const fill: { value: Filter }[] = [{ value: "new" }, { value: "tes" }];

export default function TransactionsScreen() {
  const [filter, setFillter] = useState<Filter>("new");
  return (
    <View style={styles.header}>
      <Text style={styles.title}>New Gaes</Text>
      <Pressable style={styles.profileButton} onPress={() => {}}>
        New Dynamic Route
      </Pressable>
    </View>
  );
}
